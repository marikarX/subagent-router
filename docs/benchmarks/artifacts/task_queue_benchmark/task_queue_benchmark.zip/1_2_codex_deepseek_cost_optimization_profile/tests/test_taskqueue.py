"""Focused tests for the taskqueue distributed task queue."""

import io
import socket
import threading
import time
import unittest

from taskqueue import QueueClient, QueueCoordinator, TaskQueue, TaskStatus, Worker
from taskqueue.protocol import (
    MAX_DEPTH,
    MAX_KEYS_PER_OBJECT,
    MAX_LINE_BYTES,
    ProtocolError,
    read_json_line,
)


class TaskQueuePriorityTests(unittest.TestCase):
    def test_lower_priority_number_is_reserved_first_with_fifo_tiebreak(self):
        queue = TaskQueue()
        low = queue.submit("job", {"name": "low"}, priority=50)
        first = queue.submit("job", {"name": "first"}, priority=10)
        second = queue.submit("job", {"name": "second"}, priority=10)

        self.assertEqual(queue.reserve("w1", timeout=0).id, first.id)
        self.assertEqual(queue.reserve("w2", timeout=0).id, second.id)
        self.assertEqual(queue.reserve("w3", timeout=0).id, low.id)

    def test_concurrent_reservations_maintain_priority_order(self):
        queue = TaskQueue()
        expected = []
        for priority in range(5):
            for offset in range(20):
                expected.append(
                    queue.submit("job", {"priority": priority, "offset": offset}, priority=priority).id
                )

        reserved = []
        lock = threading.Lock()

        def consumer(worker_index):
            while True:
                task = queue.reserve(f"worker-{worker_index}", timeout=0)
                if task is None:
                    return
                with lock:
                    reserved.append((task.priority, task.id))
                queue.complete(task.id, f"worker-{worker_index}")

        threads = [threading.Thread(target=consumer, args=(i,)) for i in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)

        self.assertEqual(len(reserved), len(expected))
        self.assertEqual(len({task_id for _, task_id in reserved}), len(expected))
        priorities = [p for p, _ in reserved]
        self.assertEqual(priorities, sorted(priorities))

    def test_stale_worker_requeues_reserved_task(self):
        queue = TaskQueue()
        task = queue.submit("job", priority=1)
        reserved = queue.reserve("stale-worker", timeout=0)
        self.assertEqual(reserved.id, task.id)

        queue._workers["stale-worker"].last_heartbeat = time.time() - 100
        self.assertEqual(queue.reap_stale_workers(heartbeat_timeout=1), ["stale-worker"])

        retried = queue.reserve("fresh-worker", timeout=0)
        self.assertEqual(retried.id, task.id)
        self.assertEqual(retried.attempts, 2)

    def test_reap_race_completion_after_requeue(self):
        """Simulate the race: reap requeues a task, then the worker completes it."""
        queue = TaskQueue()
        task = queue.submit("job", priority=1)
        queue.reserve("w1", timeout=0)
        self.assertEqual(task.status, TaskStatus.RESERVED)

        # reap requeues the task and clears active_task_id
        queue._workers["w1"].last_heartbeat = time.time() - 100
        reaped = queue.reap_stale_workers(heartbeat_timeout=1)
        self.assertIn("w1", reaped)
        self.assertEqual(task.status, TaskStatus.QUEUED)
        # Worker removed from _workers; previous_worker_id recorded on task
        self.assertIsNone(queue._workers.get("w1"))
        self.assertEqual(task.previous_worker_id, "w1")

        # worker's completion arrives after requeue — grace path handles it
        completed = queue.complete(task.id, "w1", result=42)
        self.assertEqual(completed.status, TaskStatus.COMPLETED)
        self.assertEqual(completed.result, 42)

    def test_reap_race_fail_after_requeue(self):
        """Simulate the race: reap requeues a task, then the worker fails it."""
        queue = TaskQueue()
        task = queue.submit("job", priority=1, max_attempts=1)
        queue.reserve("w1", timeout=0)
        self.assertEqual(task.status, TaskStatus.RESERVED)

        # reap requeues the task
        queue._workers["w1"].last_heartbeat = time.time() - 100
        queue.reap_stale_workers(heartbeat_timeout=1)
        self.assertEqual(task.status, TaskStatus.QUEUED)

        # worker's fail arrives after requeue — should be graceful
        failed = queue.fail(task.id, "w1", "too slow")
        self.assertEqual(failed.status, TaskStatus.FAILED)

    def test_reap_non_stale_worker_not_affected(self):
        """Worker with fresh heartbeat should not be reaped."""
        queue = TaskQueue()
        task = queue.submit("job", priority=1)
        queue.reserve("w1", timeout=0)
        queue._workers["w1"].last_heartbeat = time.time()
        reaped = queue.reap_stale_workers(heartbeat_timeout=10)
        self.assertNotIn("w1", reaped)
        self.assertEqual(task.status, TaskStatus.RESERVED)


class CoordinatorClientTests(unittest.TestCase):
    def test_tcp_lifecycle_and_worker_heartbeat(self):
        with QueueCoordinator(max_connections=10) as coordinator:
            host, port = coordinator.address
            with QueueClient(host, port) as client:
                submitted = client.submit("add", {"a": 2, "b": 3}, priority=1)
                self.assertEqual(submitted.status, TaskStatus.QUEUED)

                task = client.reserve("worker-1", timeout=0)
                self.assertEqual(task.id, submitted.id)
                client.heartbeat("worker-1")
                completed = client.complete(task.id, "worker-1", result=5)
                self.assertEqual(completed.status, TaskStatus.COMPLETED)
                self.assertEqual(client.get_task(task.id).result, 5)

    def test_worker_executes_registered_handler(self):
        with QueueCoordinator(max_connections=10) as coordinator:
            host, port = coordinator.address
            with QueueClient(host, port) as client:
                task = client.submit("double", {"value": 21}, priority=1)
            worker = Worker(
                host, port, {"double": lambda payload: payload["value"] * 2}, worker_id="worker-double"
            )
            try:
                worker.run_once(timeout=0)
            finally:
                worker.stop()
            with QueueClient(host, port) as client:
                completed = client.get_task(task.id)
                self.assertEqual(completed.status, TaskStatus.COMPLETED)
                self.assertEqual(completed.result, 42)

    def test_max_connections_rejects_excess_clients_and_recovers_after_close(self):
        with QueueCoordinator(max_connections=1) as coordinator:
            host, port = coordinator.address
            first = socket.create_connection((host, port), timeout=2)
            try:
                deadline = time.time() + 2
                while coordinator.active_connections != 1 and time.time() < deadline:
                    time.sleep(0.01)
                second = socket.create_connection((host, port), timeout=2)
                try:
                    second.settimeout(2)
                    response = second.recv(1024)
                    self.assertIn(b"server at capacity", response)
                finally:
                    second.close()
            finally:
                first.close()

            deadline = time.time() + 2
            while coordinator.active_connections != 0 and time.time() < deadline:
                time.sleep(0.01)
            with QueueClient(host, port) as client:
                self.assertIn("stats", client.stats())

    def test_idle_client_timeout_closes_without_poisoning_next_client(self):
        with QueueCoordinator(max_connections=1) as coordinator:
            old_timeout = coordinator._server.RequestHandlerClass.timeout
            coordinator._server.RequestHandlerClass.timeout = 0.1
            try:
                host, port = coordinator.address
                idle = socket.create_connection((host, port), timeout=2)
                try:
                    deadline = time.time() + 2
                    while coordinator.active_connections != 1 and time.time() < deadline:
                        time.sleep(0.01)
                    self.assertEqual(coordinator.active_connections, 1)
                    deadline = time.time() + 2
                    while coordinator.active_connections != 0 and time.time() < deadline:
                        time.sleep(0.01)
                    self.assertEqual(coordinator.active_connections, 0)
                finally:
                    idle.close()
            finally:
                coordinator._server.RequestHandlerClass.timeout = old_timeout

            with QueueClient(host, port) as client:
                self.assertIn("stats", client.stats())

    def test_client_closes_dead_socket_after_protocol_failure(self):
        class BrokenReader:
            def readline(self, limit=-1):
                raise ProtocolError("bad frame")

        client = QueueClient("127.0.0.1", 1)
        client._sock = io.BytesIO()
        client._reader = BrokenReader()
        client._writer = io.BytesIO()
        with self.assertRaises(ProtocolError):
            client.request(action="stats")
        self.assertIsNone(client._sock)
        self.assertIsNone(client._reader)
        self.assertIsNone(client._writer)

    def test_client_closes_socket_on_runtime_error_response(self):
        """Socket NOT closed on logical RuntimeError from coordinator."""
        with QueueCoordinator(max_connections=10) as coordinator:
            host, port = coordinator.address
            client = QueueClient(host, port, timeout=2)
            client.connect()
            self.assertIsNotNone(client._sock)
            with self.assertRaises(RuntimeError):
                client.request(action="nonexistent")
            # Socket should remain open — RuntimeError is logical, not transport
            self.assertIsNotNone(client._sock, "socket must remain open after logical RuntimeError")
            client.close()

    def test_client_partial_connect_cleanup(self):
        """connect() cleans up after partial failure."""
        client = QueueClient("127.0.0.1", 1, timeout=0.01)
        with self.assertRaises(OSError):
            client.connect()
        self.assertIsNone(client._sock)
        self.assertIsNone(client._reader)
        self.assertIsNone(client._writer)


class DeregisterTests(unittest.TestCase):
    def test_deregister_unknown_worker(self):
        queue = TaskQueue()
        self.assertFalse(queue.deregister("nonexistent"))

    def test_deregister_worker_with_active_task(self):
        queue = TaskQueue()
        task = queue.submit("job", priority=1)
        queue.reserve("w1", timeout=0)
        self.assertEqual(task.status, TaskStatus.RESERVED)

        ok = queue.deregister("w1")
        self.assertTrue(ok)
        self.assertEqual(task.status, TaskStatus.QUEUED)
        self.assertNotIn("w1", queue.workers())
        self.assertIsNone(task.worker_id)

    def test_deregister_idle_worker(self):
        queue = TaskQueue()
        queue.heartbeat("w1")
        self.assertIn("w1", queue.workers())
        ok = queue.deregister("w1")
        self.assertTrue(ok)
        self.assertNotIn("w1", queue.workers())

    def test_deregister_tcp(self):
        with QueueCoordinator(max_connections=10) as coordinator:
            host, port = coordinator.address
            with QueueClient(host, port) as client:
                client.heartbeat("worker-to-deregister")
            with QueueClient(host, port) as client:
                ok = client.deregister("worker-to-deregister")
                self.assertTrue(ok)


class PruneCompletedTests(unittest.TestCase):
    def test_prune_removes_completed_and_failed_tasks(self):
        queue = TaskQueue()
        t1 = queue.submit("a", priority=1)
        t2 = queue.submit("b", priority=1)
        t3 = queue.submit("c", priority=1)

        queue.reserve("w1", timeout=0)
        queue.complete(t1.id, "w1")
        queue.reserve("w2", timeout=0)
        queue.complete(t2.id, "w2")

        self.assertEqual(queue.prune_completed(), 2)
        self.assertIsNone(queue.get_task(t1.id))
        self.assertIsNone(queue.get_task(t2.id))
        self.assertIsNotNone(queue.get_task(t3.id))

    def test_prune_only_old_tasks_with_max_age(self):
        queue = TaskQueue()
        t1 = queue.submit("a", priority=1)
        t2 = queue.submit("b", priority=1)

        queue.reserve("w1", timeout=0)
        queue.complete(t1.id, "w1")

        queue.reserve("w2", timeout=0)
        queue.complete(t2.id, "w2")

        # Both are very recent — max_age=10 should keep both
        self.assertEqual(queue.prune_completed(max_age=10), 0)
        self.assertIsNotNone(queue.get_task(t1.id))
        self.assertIsNotNone(queue.get_task(t2.id))

    def test_max_tasks_limit(self):
        queue = TaskQueue(max_tasks=2)
        queue.submit("a", priority=1)
        queue.submit("b", priority=1)
        with self.assertRaises(RuntimeError):
            queue.submit("c", priority=1)


    def test_prune_also_cleans_heap_entries(self):
        """prune_completed removes stale heap entries after reap race."""
        queue = TaskQueue()
        t1 = queue.submit("a", priority=1)

        # Reserve → reap requeues (adds heap entry) → complete via grace
        queue.reserve("w1", timeout=0)
        queue._workers["w1"].last_heartbeat = time.time() - 100
        queue.reap_stale_workers(heartbeat_timeout=1)
        # T1 is QUEUED with a new heap entry added by reap
        queue.complete(t1.id, "w1")
        # T1 is COMPLETED; heap has the stale entry from reap

        # Stale heap entry exists (reap added it, complete didn't re-pop)
        self.assertGreater(len(queue._heap), 0)

        # Prune removes the task and the stale heap entry
        pruned = queue.prune_completed()
        self.assertEqual(pruned, 1)

        # Heap should be clean (no stale entries)
        for entry in queue._heap:
            task = queue._tasks.get(entry[3])
            if task is None or task.status != TaskStatus.QUEUED:
                self.fail(f"heap has stale entry for {entry[3]}")

    def test_prune_empty_heap_after_prune(self):
        """Pruning all completed tasks also empties the heap of stale entries."""
        queue = TaskQueue()
        t1 = queue.submit("a", priority=1)

        queue.reserve("w1", timeout=0)
        queue.complete(t1.id, "w1")

        queue.prune_completed()
        self.assertIsNone(queue.get_task(t1.id))
        # Heap should have no stale entries
        for entry in queue._heap:
            _, _, _, tid = entry
            self.assertIsNotNone(queue.get_task(tid), f"heap entry for missing task {tid}")


class ProtocolHardeningTests(unittest.TestCase):
    def test_oversized_request_is_rejected_before_json_decode(self):
        payload = b"x" * (MAX_LINE_BYTES + 1) + b"\n"
        with self.assertRaises(ProtocolError):
            read_json_line(io.BytesIO(payload))

    def test_invalid_utf8_is_rejected(self):
        with self.assertRaises(ProtocolError):
            read_json_line(io.BytesIO(b"\xff\n"))

    def test_deep_nesting_rejected(self):
        obj = {}
        cur = obj
        for _ in range(MAX_DEPTH + 1):
            cur["x"] = {}
            cur = cur["x"]
        line = (__import__("json").dumps(obj, separators=(",", ":")) + "\n").encode()
        with self.assertRaises(ProtocolError):
            read_json_line(io.BytesIO(line))

    def test_excessive_keys_rejected(self):
        obj = {str(i): i for i in range(MAX_KEYS_PER_OBJECT + 1)}
        line = (__import__("json").dumps(obj, separators=(",", ":")) + "\n").encode()
        with self.assertRaises(ProtocolError):
            read_json_line(io.BytesIO(line))


if __name__ == "__main__":
    unittest.main()
