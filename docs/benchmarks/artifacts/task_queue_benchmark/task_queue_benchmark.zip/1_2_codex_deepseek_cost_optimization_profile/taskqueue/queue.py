"""Thread-safe priority queue state for the coordinator."""

from __future__ import annotations

from dataclasses import dataclass
import heapq
import itertools
import threading
from typing import Any

from .task import Task, TaskStatus, _now


@dataclass(slots=True)
class WorkerState:
    worker_id: str
    last_heartbeat: float
    active_task_id: str | None = None


class TaskQueue:
    """A condition-protected priority heap with task lifecycle tracking."""

    def __init__(self, max_tasks: int = 0) -> None:
        if max_tasks < 0:
            raise ValueError("max_tasks must be >= 0")
        self._max_tasks = max_tasks
        self._condition = threading.Condition(threading.RLock())
        self._counter = itertools.count()
        self._heap: list[tuple[int, float, int, str]] = []
        self._tasks: dict[str, Task] = {}
        self._workers: dict[str, WorkerState] = {}

    def submit(
        self,
        name: str,
        payload: dict[str, Any] | None = None,
        priority: int = 100,
        max_attempts: int = 3,
    ) -> Task:
        task = Task(
            name=name,
            payload=payload or {},
            priority=priority,
            max_attempts=max_attempts,
        )
        with self._condition:
            if self._max_tasks and len(self._tasks) >= self._max_tasks:
                raise RuntimeError(f"task queue at capacity ({self._max_tasks})")
            self._tasks[task.id] = task
            self._push_locked(task)
            self._condition.notify()
            return task

    def reserve(self, worker_id: str, timeout: float | None = None) -> Task | None:
        deadline = None if timeout is None else _now() + timeout
        with self._condition:
            self.heartbeat(worker_id)
            while True:
                task = self._pop_ready_locked()
                if task is not None:
                    task.status = TaskStatus.RESERVED
                    task.attempts += 1
                    task.worker_id = worker_id
                    task.updated_at = _now()
                    self._workers[worker_id].active_task_id = task.id
                    return task
                if timeout == 0:
                    return None
                if deadline is None:
                    self._condition.wait()
                else:
                    remaining = deadline - _now()
                    if remaining <= 0:
                        return None
                    self._condition.wait(remaining)

    def complete(self, task_id: str, worker_id: str, result: Any = None) -> Task:
        with self._condition:
            self.heartbeat(worker_id)
            task = self._require_reserved_by_locked(task_id, worker_id)
            task.status = TaskStatus.COMPLETED
            task.result = result
            task.error = None
            task.updated_at = _now()
            task.previous_worker_id = None
            self._clear_worker_task_locked(worker_id, task_id)
            return task

    def fail(self, task_id: str, worker_id: str, error: str) -> Task:
        with self._condition:
            self.heartbeat(worker_id)
            task = self._require_reserved_by_locked(task_id, worker_id)
            task.error = str(error)
            task.updated_at = _now()
            task.previous_worker_id = None
            self._clear_worker_task_locked(worker_id, task_id)
            if task.attempts < task.max_attempts:
                task.status = TaskStatus.QUEUED
                task.worker_id = None
                self._push_locked(task)
                self._condition.notify()
            else:
                task.status = TaskStatus.FAILED
            return task

    def heartbeat(self, worker_id: str) -> WorkerState:
        if not worker_id:
            raise ValueError("worker_id is required")
        with self._condition:
            state = self._workers.get(worker_id)
            if state is None:
                state = WorkerState(worker_id=worker_id, last_heartbeat=_now())
                self._workers[worker_id] = state
            else:
                state.last_heartbeat = _now()
            return state

    def deregister(self, worker_id: str) -> bool:
        """Remove a worker and requeue its active task if still reserved."""
        with self._condition:
            state = self._workers.pop(worker_id, None)
            if state is None:
                return False
            task_id = state.active_task_id
            if task_id:
                task = self._tasks.get(task_id)
                if task and task.status == TaskStatus.RESERVED:
                    task.previous_worker_id = task.worker_id
                    task.status = TaskStatus.QUEUED
                    task.worker_id = None
                    task.updated_at = _now()
                    self._push_locked(task)
                    self._condition.notify()
            return True

    def reap_stale_workers(self, heartbeat_timeout: float) -> list[str]:
        cutoff = _now() - heartbeat_timeout
        reaped: list[str] = []
        with self._condition:
            for worker_id, state in list(self._workers.items()):
                if state.last_heartbeat >= cutoff:
                    continue
                task_id = state.active_task_id
                if task_id:
                    task = self._tasks.get(task_id)
                    if task and task.status == TaskStatus.RESERVED:
                        task.previous_worker_id = task.worker_id
                        task.status = TaskStatus.QUEUED
                        task.worker_id = None
                        task.updated_at = _now()
                        self._push_locked(task)
                del self._workers[worker_id]
                reaped.append(worker_id)
            if reaped:
                self._condition.notify_all()
            return reaped

    def prune_completed(self, max_age: float = 0) -> int:
        """Remove completed/failed tasks from _tasks to bound memory growth.

        Args:
            max_age: Only prune tasks older than this many seconds.
                     Pass 0 (default) to prune all completed/failed tasks.
        Returns:
            Number of tasks pruned.
        """
        cutoff = _now() - max_age if max_age > 0 else float("inf")
        pruned = 0
        with self._condition:
            to_delete = [
                tid
                for tid, t in self._tasks.items()
                if t.status in (TaskStatus.COMPLETED, TaskStatus.FAILED)
                and t.updated_at <= cutoff
            ]
            for tid in to_delete:
                del self._tasks[tid]
                pruned += 1
            if pruned:
                self._prune_heap_locked()
        return pruned

    def _prune_heap_locked(self) -> None:
        """Remove heap entries for tasks no longer QUEUED or no longer in _tasks."""
        self._heap = [
            entry for entry in self._heap
            if (task := self._tasks.get(entry[3])) is not None
            and task.status == TaskStatus.QUEUED
        ]
        heapq.heapify(self._heap)

    def get_task(self, task_id: str) -> Task | None:
        with self._condition:
            return self._tasks.get(task_id)

    def workers(self) -> dict[str, WorkerState]:
        with self._condition:
            return dict(self._workers)

    def stats(self) -> dict[str, int]:
        with self._condition:
            statuses = {status.value: 0 for status in TaskStatus}
            for task in self._tasks.values():
                statuses[task.status.value] += 1
            statuses["workers"] = len(self._workers)
            statuses["queued_heap_entries"] = len(self._heap)
            return statuses

    def _push_locked(self, task: Task) -> None:
        heapq.heappush(self._heap, (task.priority, task.created_at, next(self._counter), task.id))

    def _pop_ready_locked(self) -> Task | None:
        while self._heap:
            _, _, _, task_id = heapq.heappop(self._heap)
            task = self._tasks.get(task_id)
            if task is not None and task.status == TaskStatus.QUEUED:
                return task
        return None

    def _require_reserved_by_locked(self, task_id: str, worker_id: str) -> Task:
        task = self._tasks.get(task_id)
        if task is None:
            raise KeyError(f"unknown task: {task_id}")
        if task.status == TaskStatus.RESERVED and task.worker_id == worker_id:
            return task
        # Grace: task was requeued by reap_stale_workers or deregister
        # while this worker's completion/fail was in-flight.
        if (task.status == TaskStatus.QUEUED
                and task.worker_id is None
                and task.previous_worker_id == worker_id):
            return task
        raise ValueError("task is not reserved by this worker")

    def _clear_worker_task_locked(self, worker_id: str, task_id: str) -> None:
        state = self._workers.get(worker_id)
        if state and state.active_task_id == task_id:
            state.active_task_id = None
