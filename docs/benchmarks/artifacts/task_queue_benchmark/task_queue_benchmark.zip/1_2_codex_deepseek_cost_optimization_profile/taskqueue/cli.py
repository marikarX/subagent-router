"""Minimal command-line entry points."""

from __future__ import annotations

import argparse
import signal
import time

from .coordinator import QueueCoordinator


def main() -> None:
    parser = argparse.ArgumentParser(prog="taskqueue")
    subcommands = parser.add_subparsers(dest="command", required=True)
    serve = subcommands.add_parser("serve")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()

    if args.command == "serve":
        stop = False

        def _stop(signum: int, frame: object) -> None:
            nonlocal stop
            stop = True

        signal.signal(signal.SIGTERM, _stop)
        signal.signal(signal.SIGINT, _stop)
        coordinator = QueueCoordinator(args.host, args.port).start()
        print(
            f"taskqueue coordinator listening on {coordinator.address[0]}:{coordinator.address[1]}",
            flush=True,
        )
        try:
            while not stop:
                coordinator.queue.reap_stale_workers(30)
                time.sleep(1)
        finally:
            coordinator.stop()
