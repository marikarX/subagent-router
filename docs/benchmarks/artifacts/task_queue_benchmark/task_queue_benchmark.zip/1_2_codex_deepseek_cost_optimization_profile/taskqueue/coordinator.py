"""TCP coordinator for distributed workers and clients."""

from __future__ import annotations

import socket
import socketserver
import threading
from typing import Any

from .protocol import ProtocolError, read_json_line, send_json_line
from .queue import TaskQueue


class _QueueTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, server_address: tuple[str, int], queue: TaskQueue, max_connections: int) -> None:
        self.queue = queue
        self.max_connections = max_connections
        self.connection_count = 0
        self.active_connections: set[socket.socket] = set()
        self._connection_lock = threading.Lock()
        super().__init__(server_address, _QueueRequestHandler)

    def verify_request(self, request: socket.socket, client_address: tuple[str, int]) -> bool:
        with self._connection_lock:
            if self.connection_count >= self.max_connections:
                try:
                    request.sendall(b'{"ok":false,"error":"server at capacity"}\n')
                except OSError:
                    pass
                return False
            self.connection_count += 1
            self.active_connections.add(request)
            return True

    def process_request_thread(self, request: socket.socket, client_address: tuple[str, int]) -> None:
        try:
            super().process_request_thread(request, client_address)
        finally:
            with self._connection_lock:
                self.connection_count = max(0, self.connection_count - 1)
                self.active_connections.discard(request)

    def server_close(self) -> None:
        with self._connection_lock:
            sockets = list(self.active_connections)
            self.active_connections.clear()
            self.connection_count = 0
        for sock in sockets:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass
        super().server_close()


class _QueueRequestHandler(socketserver.StreamRequestHandler):
    timeout = 30

    def handle(self) -> None:
        self.request.settimeout(self.timeout)
        reader = self.rfile
        writer = self.wfile
        while True:
            try:
                request = read_json_line(reader)
                if request is None:
                    return
                response = self._dispatch(request)
            except ProtocolError as exc:
                response = {"ok": False, "error": str(exc)}
            except socket.timeout:
                return
            except OSError:
                return
            except Exception as exc:
                response = {"ok": False, "error": str(exc)}
            try:
                send_json_line(writer, response)
            except OSError:
                return

    def _dispatch(self, request: dict[str, Any]) -> dict[str, Any]:
        action = request.get("action")
        queue: TaskQueue = self.server.queue  # type: ignore[attr-defined]
        if action == "submit":
            task = queue.submit(
                name=str(request["name"]),
                payload=request.get("payload") or {},
                priority=int(request.get("priority", 100)),
                max_attempts=int(request.get("max_attempts", 3)),
            )
            return {"ok": True, "task": task.to_dict()}
        if action == "reserve":
            task = queue.reserve(
                worker_id=str(request["worker_id"]),
                timeout=float(request.get("timeout", 0)),
            )
            return {"ok": True, "task": None if task is None else task.to_dict()}
        if action == "complete":
            task = queue.complete(
                task_id=str(request["task_id"]),
                worker_id=str(request["worker_id"]),
                result=request.get("result"),
            )
            return {"ok": True, "task": task.to_dict()}
        if action == "fail":
            task = queue.fail(
                task_id=str(request["task_id"]),
                worker_id=str(request["worker_id"]),
                error=str(request.get("error", "")),
            )
            return {"ok": True, "task": task.to_dict()}
        if action == "heartbeat":
            state = queue.heartbeat(worker_id=str(request["worker_id"]))
            return {
                "ok": True,
                "worker": {
                    "worker_id": state.worker_id,
                    "last_heartbeat": state.last_heartbeat,
                    "active_task_id": state.active_task_id,
                },
            }
        if action == "deregister":
            ok = queue.deregister(worker_id=str(request["worker_id"]))
            return {"ok": ok}
        if action == "reap":
            return {"ok": True, "reaped": queue.reap_stale_workers(float(request["timeout"]))}
        if action == "prune":
            max_age = float(request.get("max_age", 0))
            count = queue.prune_completed(max_age=max_age)
            return {"ok": True, "pruned": count}
        if action == "get_task":
            task = queue.get_task(str(request["task_id"]))
            return {"ok": True, "task": None if task is None else task.to_dict()}
        if action == "stats":
            return {
                "ok": True,
                "stats": queue.stats(),
                "connections": self.server.connection_count,  # type: ignore[attr-defined]
            }
        raise ProtocolError(f"unknown action: {action}")


class QueueCoordinator:
    """Owns a queue and serves it over TCP."""

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 0,
        queue: TaskQueue | None = None,
        max_connections: int = 100,
    ) -> None:
        if max_connections < 1:
            raise ValueError("max_connections must be at least 1")
        self.queue = queue or TaskQueue()
        self._server = _QueueTCPServer((host, port), self.queue, max_connections)
        self._thread: threading.Thread | None = None

    @property
    def address(self) -> tuple[str, int]:
        host, port = self._server.server_address[:2]
        return str(host), int(port)

    def start(self) -> "QueueCoordinator":
        if self._thread is not None:
            return self
        self._thread = threading.Thread(
            target=self._server.serve_forever, name="queue-coordinator", daemon=True
        )
        self._thread.start()
        return self

    def stop(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None

    @property
    def active_connections(self) -> int:
        return self._server.connection_count

    def __enter__(self) -> "QueueCoordinator":
        return self.start()

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.stop()
