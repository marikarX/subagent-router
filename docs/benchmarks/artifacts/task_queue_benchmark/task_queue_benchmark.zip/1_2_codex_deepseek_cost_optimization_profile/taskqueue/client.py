"""Client for the queue coordinator."""

from __future__ import annotations

from typing import Any

from .protocol import ProtocolError, read_json_line, send_json_line, socket_pair
from .task import Task


class QueueClient:
    def __init__(self, host: str, port: int, timeout: float = 5) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout
        self._sock = None
        self._reader = None
        self._writer = None

    def connect(self) -> "QueueClient":
        if self._sock is None:
            sock = None
            try:
                sock = socket_pair(self.host, self.port, self.timeout)
                self._reader = sock.makefile("rb")
                self._writer = sock.makefile("wb")
                self._sock = sock
            except OSError:
                for h in (getattr(self, "_reader", None),
                          getattr(self, "_writer", None)):
                    if h is not None:
                        try:
                            h.close()
                        except OSError:
                            pass
                if sock is not None:
                    try:
                        sock.close()
                    except OSError:
                        pass
                self._reader = None
                self._writer = None
                self._sock = None
                raise
        return self

    def close(self) -> None:
        for handle in (self._reader, self._writer, self._sock):
            if handle is not None:
                try:
                    handle.close()
                except (AttributeError, OSError):
                    pass
        self._reader = None
        self._writer = None
        self._sock = None

    def request(self, **message: Any) -> dict[str, Any]:
        try:
            self.connect()
            assert self._reader is not None
            assert self._writer is not None
            send_json_line(self._writer, message)
            response = read_json_line(self._reader)
            if response is None:
                raise ConnectionError("coordinator closed the connection")
            if not response.get("ok"):
                raise RuntimeError(str(response.get("error", "unknown coordinator error")))
            return response
        except (OSError, ProtocolError, ConnectionError):
            self.close()
            raise

    def submit(
        self,
        name: str,
        payload: dict[str, Any] | None = None,
        priority: int = 100,
        max_attempts: int = 3,
    ) -> Task:
        response = self.request(
            action="submit",
            name=name,
            payload=payload or {},
            priority=priority,
            max_attempts=max_attempts,
        )
        return Task.from_dict(response["task"])

    def reserve(self, worker_id: str, timeout: float = 0) -> Task | None:
        response = self.request(action="reserve", worker_id=worker_id, timeout=timeout)
        task = response["task"]
        return None if task is None else Task.from_dict(task)

    def complete(self, task_id: str, worker_id: str, result: Any = None) -> Task:
        response = self.request(
            action="complete", task_id=task_id, worker_id=worker_id, result=result
        )
        return Task.from_dict(response["task"])

    def fail(self, task_id: str, worker_id: str, error: str) -> Task:
        response = self.request(
            action="fail", task_id=task_id, worker_id=worker_id, error=error
        )
        return Task.from_dict(response["task"])

    def heartbeat(self, worker_id: str) -> dict[str, Any]:
        return self.request(action="heartbeat", worker_id=worker_id)["worker"]

    def deregister(self, worker_id: str) -> bool:
        return bool(self.request(action="deregister", worker_id=worker_id)["ok"])

    def reap(self, timeout: float) -> list[str]:
        return list(self.request(action="reap", timeout=timeout)["reaped"])

    def get_task(self, task_id: str) -> Task | None:
        response = self.request(action="get_task", task_id=task_id)
        task = response["task"]
        return None if task is None else Task.from_dict(task)

    def stats(self) -> dict[str, Any]:
        return self.request(action="stats")

    def __enter__(self) -> "QueueClient":
        return self.connect()

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()
