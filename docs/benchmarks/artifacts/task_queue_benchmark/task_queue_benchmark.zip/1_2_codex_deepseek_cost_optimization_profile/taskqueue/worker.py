"""Worker process logic."""

from __future__ import annotations

import threading
import time
import traceback
import uuid
from typing import Any, Callable

from .client import QueueClient
from .task import Task

Handler = Callable[[dict[str, Any]], Any]


class Worker:
    def __init__(
        self,
        host: str,
        port: int,
        handlers: dict[str, Handler],
        worker_id: str | None = None,
        heartbeat_interval: float = 1.0,
        reserve_timeout: float = 1.0,
        socket_timeout: float = 2.0,
    ) -> None:
        if heartbeat_interval <= 0:
            raise ValueError("heartbeat_interval must be positive")
        if socket_timeout <= 0:
            raise ValueError("socket_timeout must be positive")
        self.host = host
        self.port = port
        self.handlers = dict(handlers)
        self.worker_id = worker_id or uuid.uuid4().hex
        self.heartbeat_interval = heartbeat_interval
        self.reserve_timeout = reserve_timeout
        self.socket_timeout = socket_timeout
        self._stop = threading.Event()
        self._heartbeat_thread: threading.Thread | None = None
        self._client = QueueClient(host, port, timeout=socket_timeout)

    def start_heartbeats(self) -> None:
        if self._heartbeat_thread is not None:
            return
        self._heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop, name=f"heartbeat-{self.worker_id}", daemon=True
        )
        self._heartbeat_thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._heartbeat_thread is not None:
            self._heartbeat_thread.join(timeout=self.socket_timeout + 1)
            if not self._heartbeat_thread.is_alive():
                self._heartbeat_thread = None
        self._client.close()

    def run_forever(self) -> None:
        self.start_heartbeats()
        try:
            while not self._stop.is_set():
                self.run_once(timeout=self.reserve_timeout)
        finally:
            self.stop()

    def run_once(self, timeout: float = 0) -> Task | None:
        self.start_heartbeats()
        task = self._client.reserve(self.worker_id, timeout=timeout)
        if task is None:
            return None
        handler = self.handlers.get(task.name)
        if handler is None:
            self._client.fail(task.id, self.worker_id, f"no handler registered for {task.name}")
            return task
        try:
            result = handler(task.payload)
        except Exception:
            self._client.fail(task.id, self.worker_id, traceback.format_exc(limit=20))
        else:
            self._client.complete(task.id, self.worker_id, result=result)
        return task

    def _heartbeat_loop(self) -> None:
        while not self._stop.is_set():
            try:
                with QueueClient(self.host, self.port, timeout=self.socket_timeout) as client:
                    client.heartbeat(self.worker_id)
            except Exception:
                pass
            self._stop.wait(self.heartbeat_interval)

    def __enter__(self) -> "Worker":
        self.start_heartbeats()
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.stop()
