"""JSON-lines socket protocol helpers."""

from __future__ import annotations

import json
import socket
from typing import Any, BinaryIO

MAX_LINE_BYTES = 1024 * 1024
MAX_DEPTH = 20
MAX_KEYS_PER_OBJECT = 1000
MAX_ITEMS_PER_ARRAY = 100_000


class ProtocolError(ValueError):
    pass


class _ValidationError(ValueError):
    pass


def _validate_json_structure(obj: Any, depth: int = 0) -> None:
    """Validate JSON structure against DoS limits."""
    if depth > MAX_DEPTH:
        raise _ValidationError(f"json exceeds max nesting depth {MAX_DEPTH}")
    if isinstance(obj, dict):
        if len(obj) > MAX_KEYS_PER_OBJECT:
            raise _ValidationError(
                f"dict exceeds max keys {MAX_KEYS_PER_OBJECT}: {len(obj)}"
            )
        for value in obj.values():
            _validate_json_structure(value, depth + 1)
    elif isinstance(obj, list):
        if len(obj) > MAX_ITEMS_PER_ARRAY:
            raise _ValidationError(
                f"list exceeds max items {MAX_ITEMS_PER_ARRAY}: {len(obj)}"
            )
        for item in obj:
            _validate_json_structure(item, depth + 1)


def read_json_line(reader: BinaryIO) -> dict[str, Any] | None:
    line = reader.readline(MAX_LINE_BYTES + 1)
    if line == b"":
        return None
    if len(line) > MAX_LINE_BYTES:
        raise ProtocolError("request too large")
    try:
        message = json.loads(line.decode("utf-8"))
    except UnicodeDecodeError as exc:
        raise ProtocolError("request must be utf-8") from exc
    except json.JSONDecodeError as exc:
        raise ProtocolError("invalid json") from exc
    if not isinstance(message, dict):
        raise ProtocolError("message must be an object")
    try:
        _validate_json_structure(message)
    except _ValidationError as exc:
        raise ProtocolError(str(exc)) from exc
    return message


def send_json_line(writer: BinaryIO, message: dict[str, Any]) -> None:
    writer.write(json.dumps(message, separators=(",", ":")).encode("utf-8") + b"\n")
    writer.flush()


def socket_pair(host: str, port: int, timeout: float) -> socket.socket:
    sock = socket.create_connection((host, port), timeout=timeout)
    sock.settimeout(timeout)
    return sock
