"""Task data structures and validation."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
import time
import uuid
from typing import Any


class TaskStatus(StrEnum):
    QUEUED = "queued"
    RESERVED = "reserved"
    COMPLETED = "completed"
    FAILED = "failed"


def _now() -> float:
    return time.time()


@dataclass(slots=True)
class Task:
    name: str
    payload: dict[str, Any] = field(default_factory=dict)
    priority: int = 100
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    status: TaskStatus = TaskStatus.QUEUED
    created_at: float = field(default_factory=_now)
    updated_at: float = field(default_factory=_now)
    attempts: int = 0
    max_attempts: int = 3
    worker_id: str | None = None
    result: Any = None
    error: str | None = None
    previous_worker_id: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name:
            raise ValueError("task name must be a non-empty string")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "payload": self.payload,
            "priority": self.priority,
            "status": self.status.value,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "attempts": self.attempts,
            "max_attempts": self.max_attempts,
            "worker_id": self.worker_id,
            "result": self.result,
            "error": self.error,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Task":
        return cls(
            id=str(data["id"]),
            name=str(data["name"]),
            payload=dict(data.get("payload", {})),
            priority=int(data.get("priority", 100)),
            status=TaskStatus(data.get("status", TaskStatus.QUEUED)),
            created_at=float(data.get("created_at", _now())),
            updated_at=float(data.get("updated_at", _now())),
            attempts=int(data.get("attempts", 0)),
            max_attempts=int(data.get("max_attempts", 3)),
            worker_id=data.get("worker_id"),
            result=data.get("result"),
            error=data.get("error"),
        )
