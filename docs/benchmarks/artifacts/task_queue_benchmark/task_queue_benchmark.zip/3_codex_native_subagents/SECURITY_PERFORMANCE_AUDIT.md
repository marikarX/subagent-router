# Security and Performance Audit

## Priority Queue Race Conditions

- All heap mutation and task state transitions happen under one
  `Condition`/`RLock` in `_QueueState`.
- `submit`, `fetch`, explicit failure requeue, and stale-worker requeue all use
  the same lock before calling `heapq`.
- `fetch` marks the popped task `running` and records the worker assignment
  before releasing the lock, so two workers cannot receive the same queued task.
- Stale heap entries are tolerated and skipped by `_pop_locked` if the task is
  no longer in `queued` state.
- Higher numeric priority is implemented by storing negative priorities in the
  min-heap.
- FIFO ordering within a priority is stable through a monotonic sequence number
  stored in heap entries.
- If a worker fetch response cannot be written to the socket, the broker
  immediately requeues that just-assigned task under the queue lock instead of
  waiting for heartbeat expiry.

Residual risk: this is an in-memory broker. A process crash loses queue state and
in-flight ownership data.

## Socket-Level Resource and Memory Review

- The protocol caps inbound and outbound JSON messages at 1 MiB.
- Server handlers use `StreamRequestHandler`, one request per connection, and
  `daemon_threads = True`; `server_close()` closes the listening socket.
- Client requests use nested context managers for both the socket and the file
  wrapper returned by `makefile()`.
- The broker applies socket timeouts to avoid permanently blocked handler
  threads on idle or partial clients.
- There is no unbounded per-connection buffer beyond the capped line read.

Residual risk: the broker creates one thread per accepted connection. A hostile
client can still consume thread slots by opening many connections up to OS and
process limits. Production use should put this behind connection limits or move
to a selector-based server.

## Performance Notes

- Queue operations are `O(log n)` for push/pop.
- The stale-worker scanner is `O(workers + stale_inflight)` per interval.
- The single queue lock intentionally serializes scheduling decisions. It favors
  correctness and simple reasoning over maximum multi-core throughput.
