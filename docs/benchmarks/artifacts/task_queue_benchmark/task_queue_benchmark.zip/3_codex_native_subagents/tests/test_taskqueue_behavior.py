import contextlib
import gc
import importlib
import socket
import time
import weakref

import pytest


def _taskqueue_module():
    return importlib.import_module("taskqueue")


def _call_first(obj, names, *args, **kwargs):
    for name in names:
        method = getattr(obj, name, None)
        if callable(method):
            return method(*args, **kwargs)
    raise AssertionError(
        f"{obj!r} does not expose any of the expected methods: {', '.join(names)}"
    )


def _construct_task_queue(**options):
    taskqueue = _taskqueue_module()
    queue_type = None
    for name in ("TaskQueue", "Queue", "TaskBroker"):
        candidate = getattr(taskqueue, name, None)
        if isinstance(candidate, type):
            queue_type = candidate
            break
    assert queue_type is not None, "taskqueue must expose TaskQueue, Queue, or TaskBroker"

    attempts = (
        options,
        {key: value for key, value in options.items() if value is not None},
        {},
    )
    last_error = None
    for kwargs in attempts:
        try:
            return queue_type(**kwargs)
        except TypeError as exc:
            last_error = exc
    raise AssertionError(f"could not construct {queue_type.__name__}: {last_error}")


def _shutdown(obj):
    for name in ("close", "shutdown", "stop"):
        method = getattr(obj, name, None)
        if callable(method):
            method()
            return


@contextlib.contextmanager
def _queue(**options):
    queue = _construct_task_queue(**options)
    try:
        starter = getattr(queue, "start", None)
        if callable(starter):
            starter()
        yield queue
    finally:
        _shutdown(queue)


def _enqueue(queue, payload, *, priority=0):
    try:
        return _call_first(
            queue,
            ("enqueue", "put", "submit", "add_task", "publish"),
            payload,
            priority=priority,
        )
    except TypeError:
        return _call_first(
            queue,
            ("enqueue", "put", "submit", "add_task", "publish"),
            payload,
            priority,
        )


def _reserve(queue, worker_id="worker-1"):
    reserve_names = ("reserve", "dequeue", "get", "pop", "claim")
    try:
        return _call_first(queue, reserve_names, worker_id=worker_id)
    except TypeError:
        try:
            return _call_first(queue, reserve_names, worker_id)
        except TypeError:
            return _call_first(queue, reserve_names)


def _complete(queue, task, worker_id="worker-1"):
    task_id = _task_id(task)
    try:
        return _call_first(
            queue,
            ("complete", "ack", "acknowledge", "finish", "mark_complete"),
            task_id,
            worker_id=worker_id,
        )
    except TypeError:
        try:
            return _call_first(
                queue,
                ("complete", "ack", "acknowledge", "finish", "mark_complete"),
                task_id,
                worker_id,
            )
        except TypeError:
            return _call_first(
                queue,
                ("complete", "ack", "acknowledge", "finish", "mark_complete"),
                task_id,
            )


def _fail(queue, task, worker_id="worker-1"):
    task_id = _task_id(task)
    try:
        return _call_first(
            queue,
            ("fail", "nack", "reject", "mark_failed"),
            task_id,
            worker_id=worker_id,
            requeue=True,
        )
    except TypeError:
        try:
            return _call_first(
                queue,
                ("fail", "nack", "reject", "mark_failed"),
                task_id,
                worker_id,
            )
        except TypeError:
            return _call_first(queue, ("fail", "nack", "reject", "mark_failed"), task_id)


def _heartbeat(queue, worker_id="worker-1"):
    return _call_first(queue, ("heartbeat", "touch", "renew", "ping"), worker_id)


def _reap_timeouts(queue):
    for name in ("reap_timeouts", "requeue_expired", "check_timeouts", "expire_workers"):
        method = getattr(queue, name, None)
        if callable(method):
            method()
            return


def _task_id(task):
    if isinstance(task, dict):
        for key in ("id", "task_id", "uuid"):
            if key in task:
                return task[key]
    for attr in ("id", "task_id", "uuid"):
        if hasattr(task, attr):
            return getattr(task, attr)
    if isinstance(task, tuple) and task:
        return task[0]
    return task


def _payload(task):
    if isinstance(task, dict):
        for key in ("payload", "data", "body", "args", "value"):
            if key in task:
                return task[key]
    for attr in ("payload", "data", "body", "args", "value"):
        if hasattr(task, attr):
            return getattr(task, attr)
    if isinstance(task, tuple):
        for item in task:
            if isinstance(item, dict) and "name" in item:
                return item
    return task


def _assert_no_task_available(queue):
    try:
        task = _reserve(queue, worker_id="worker-empty")
    except (TimeoutError, LookupError, IndexError):
        return
    assert task in (None, False), f"expected no available task, got {task!r}"


def test_priority_ordering_returns_highest_priority_first():
    with _queue() as queue:
        _enqueue(queue, {"name": "low"}, priority=1)
        _enqueue(queue, {"name": "high"}, priority=100)
        _enqueue(queue, {"name": "middle"}, priority=50)

        first = _reserve(queue, worker_id="priority-worker")
        second = _reserve(queue, worker_id="priority-worker")
        third = _reserve(queue, worker_id="priority-worker")

    assert [_payload(first), _payload(second), _payload(third)] == [
        {"name": "high"},
        {"name": "middle"},
        {"name": "low"},
    ]


def test_completed_tasks_are_not_delivered_again():
    with _queue() as queue:
        _enqueue(queue, {"name": "once"}, priority=10)
        task = _reserve(queue, worker_id="completion-worker")

        _complete(queue, task, worker_id="completion-worker")

        _assert_no_task_available(queue)


def test_failed_tasks_are_requeued_for_another_worker():
    with _queue() as queue:
        _enqueue(queue, {"name": "retry-me"}, priority=10)
        task = _reserve(queue, worker_id="failing-worker")

        _fail(queue, task, worker_id="failing-worker")
        retried = _reserve(queue, worker_id="retry-worker")

    assert _task_id(retried) == _task_id(task)
    assert _payload(retried) == {"name": "retry-me"}


def test_heartbeat_timeout_requeues_reserved_task():
    with _queue(heartbeat_timeout=0.05, visibility_timeout=0.05) as queue:
        _enqueue(queue, {"name": "stale-reservation"}, priority=10)
        reserved = _reserve(queue, worker_id="stale-worker")
        time.sleep(0.08)

        _reap_timeouts(queue)
        redelivered = _reserve(queue, worker_id="replacement-worker")

    assert _task_id(redelivered) == _task_id(reserved)
    assert _payload(redelivered) == {"name": "stale-reservation"}


def test_heartbeat_keeps_reserved_task_from_being_requeued_too_early():
    with _queue(heartbeat_timeout=0.08, visibility_timeout=0.08) as queue:
        _enqueue(queue, {"name": "active-reservation"}, priority=10)
        reserved = _reserve(queue, worker_id="active-worker")
        time.sleep(0.04)
        _heartbeat(queue, worker_id="active-worker")
        time.sleep(0.04)

        _reap_timeouts(queue)

        _assert_no_task_available(queue)
        _complete(queue, reserved, worker_id="active-worker")


def test_socket_client_context_manager_closes_underlying_socket_when_available():
    taskqueue = _taskqueue_module()
    client_type = getattr(taskqueue, "Client", None) or getattr(taskqueue, "TaskQueueClient", None)
    if client_type is None:
        pytest.skip("taskqueue does not expose a socket client type")

    left, right = socket.socketpair()
    try:
        client = None
        for kwargs in ({"sock": left}, {"socket": left}, {}):
            try:
                client = client_type(**kwargs)
                break
            except TypeError:
                continue
        if client is None:
            pytest.skip("client cannot be constructed with an existing socket")

        sock = getattr(client, "sock", None) or getattr(client, "socket", None) or left
        sock_ref = weakref.ref(sock)

        if hasattr(client, "__enter__") and hasattr(client, "__exit__"):
            with client:
                pass
        else:
            _shutdown(client)

        with pytest.raises(OSError):
            sock.fileno()
            sock.send(b"x")

        del client
        gc.collect()
        assert sock_ref() is None or sock_ref().fileno() == -1
    finally:
        for sock in (left, right):
            with contextlib.suppress(OSError):
                sock.close()
