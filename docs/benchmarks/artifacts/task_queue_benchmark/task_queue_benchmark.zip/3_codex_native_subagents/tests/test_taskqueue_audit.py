import os
import threading
import time

from taskqueue import Broker, BrokerConfig, QueueClient, TaskQueue


def test_concurrent_reservations_do_not_duplicate_or_lose_tasks():
    queue = TaskQueue(heartbeat_timeout=30.0)
    total = 300
    for item in range(total):
        queue.enqueue({"item": item}, priority=item % 7)

    seen = set()
    seen_lock = threading.Lock()
    errors = []

    def worker(index):
        try:
            while True:
                task = queue.reserve(worker_id=f"worker-{index}")
                if task is None:
                    return
                with seen_lock:
                    if task["id"] in seen:
                        errors.append(f"duplicate task {task['id']}")
                    seen.add(task["id"])
                queue.complete(task["id"], worker_id=f"worker-{index}")
        except Exception as exc:
            errors.append(repr(exc))

    threads = [threading.Thread(target=worker, args=(index,)) for index in range(16)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=5)

    assert errors == []
    assert len(seen) == total
    assert queue.reserve(worker_id="final-check") is None


def test_same_priority_tasks_remain_fifo():
    queue = TaskQueue()
    task_ids = [queue.enqueue({"item": item}, priority=42) for item in range(20)]

    delivered = [queue.reserve(worker_id="fifo-worker")["id"] for _ in range(20)]

    assert delivered == task_ids


def test_broker_client_connections_do_not_leave_file_descriptors_open():
    if not os.path.isdir("/proc/self/fd"):
        return

    before = len(os.listdir("/proc/self/fd"))
    broker = Broker(BrokerConfig(port=0, heartbeat_timeout=0.2, requeue_interval=0.05, socket_timeout=0.2))
    broker.start()
    try:
        client = QueueClient(*broker.address, timeout=1.0)
        task_ids = [client.submit("noop", priority=index) for index in range(80)]
        for task_id in task_ids:
            assert client.status(task_id)["state"] == "queued"
    finally:
        broker.stop()

    deadline = time.monotonic() + 2.0
    after = len(os.listdir("/proc/self/fd"))
    while after > before + 2 and time.monotonic() < deadline:
        time.sleep(0.02)
        after = len(os.listdir("/proc/self/fd"))

    assert after <= before + 2
