# Standard-Library Distributed Task Queue

This repository contains a small Python task queue built from scratch with only
standard-library modules. It provides:

- TCP broker using a JSON-lines protocol
- task prioritization, where higher numeric priority runs first
- FIFO ordering within the same priority
- worker heartbeats
- automatic requeue of tasks assigned to stale workers
- synchronous client and worker APIs

## Example

```python
from taskqueue import Broker, BrokerConfig, QueueClient, Worker

with Broker(BrokerConfig(port=9999)) as broker:
    client = QueueClient(*broker.address)
    task_id = client.submit("add", 2, 3, priority=10)

    worker = Worker(client, {"add": lambda a, b: a + b})
    worker.run_once()

    print(client.status(task_id))
```

The broker accepts one request per TCP connection. That keeps socket ownership
short-lived and ensures clients and handlers close file descriptors promptly.
