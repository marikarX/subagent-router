"""Worker loop for executing registered Python callables."""

from __future__ import annotations

import threading
import time
import traceback
import uuid
from collections.abc import Callable
from typing import Any

from .client import QueueClient


class Worker:
    def __init__(
        self,
        client: QueueClient,
        tasks: dict[str, Callable[..., Any]],
        *,
        worker_id: str | None = None,
        heartbeat_interval: float = 1.0,
        poll_timeout: float = 1.0,
    ) -> None:
        self.client = client
        self.tasks = tasks
        self.worker_id = worker_id or f"worker-{uuid.uuid4()}"
        self.heartbeat_interval = heartbeat_interval
        self.poll_timeout = poll_timeout
        self._stop = threading.Event()
        self._heartbeat_thread: threading.Thread | None = None

    def start_heartbeats(self) -> None:
        if self._heartbeat_thread is not None and self._heartbeat_thread.is_alive():
            return
        self._heartbeat_thread = threading.Thread(target=self._heartbeat_loop, name=f"{self.worker_id}-heartbeat", daemon=True)
        self._heartbeat_thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._heartbeat_thread is not None:
            self._heartbeat_thread.join(timeout=2)

    def run_forever(self) -> None:
        self.start_heartbeats()
        try:
            while not self._stop.is_set():
                self.run_once()
        finally:
            self.stop()

    def run_once(self) -> bool:
        task = self.client.fetch(self.worker_id, timeout=self.poll_timeout)
        if task is None:
            return False
        task_id = str(task["id"])
        name = str(task["name"])
        func = self.tasks.get(name)
        if func is None:
            self.client.fail(self.worker_id, task_id, f"unknown task: {name}", requeue=False)
            return True
        try:
            result = func(*task.get("args", []), **task.get("kwargs", {}))
        except Exception:
            self.client.fail(self.worker_id, task_id, traceback.format_exc(), requeue=False)
        else:
            self.client.complete(self.worker_id, task_id, result)
        return True

    def _heartbeat_loop(self) -> None:
        while not self._stop.wait(self.heartbeat_interval):
            self.client.heartbeat(self.worker_id)
