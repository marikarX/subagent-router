"""JSON-lines protocol helpers for taskqueue."""

from __future__ import annotations

import json
import socket
from typing import Any


MAX_MESSAGE_BYTES = 1_048_576


class ProtocolError(Exception):
    """Raised when a peer sends malformed or oversized protocol data."""


def send_message(sock: socket.socket, payload: dict[str, Any]) -> None:
    data = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    if len(data) > MAX_MESSAGE_BYTES:
        raise ProtocolError("message too large")
    sock.sendall(data + b"\n")


def recv_message(sock_file: Any, *, max_bytes: int = MAX_MESSAGE_BYTES) -> dict[str, Any]:
    line = sock_file.readline(max_bytes + 1)
    if not line:
        raise EOFError("peer closed connection")
    if len(line) > max_bytes:
        raise ProtocolError("message too large")
    try:
        payload = json.loads(line.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProtocolError("invalid json") from exc
    if not isinstance(payload, dict):
        raise ProtocolError("message must be a JSON object")
    return payload
