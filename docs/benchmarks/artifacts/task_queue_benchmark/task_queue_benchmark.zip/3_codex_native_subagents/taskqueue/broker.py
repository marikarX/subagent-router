"""Threaded TCP broker with priority scheduling and worker heartbeats."""

from __future__ import annotations

import heapq
import socket
import socketserver
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from .protocol import ProtocolError, recv_message, send_message


TERMINAL_STATES = {"completed", "failed"}


@dataclass(frozen=True)
class BrokerConfig:
    host: str = "127.0.0.1"
    port: int = 0
    heartbeat_timeout: float = 10.0
    requeue_interval: float = 0.25
    socket_timeout: float = 5.0


@dataclass
class TaskRecord:
    id: str
    name: str
    args: list[Any]
    kwargs: dict[str, Any]
    priority: int
    created_at: float
    payload: Any = None
    attempts: int = 0
    state: str = "queued"
    worker_id: str | None = None
    result: Any = None
    error: str | None = None
    updated_at: float = field(default_factory=time.monotonic)


class _QueueState:
    def __init__(self, heartbeat_timeout: float) -> None:
        self.heartbeat_timeout = heartbeat_timeout
        self.lock = threading.RLock()
        self.not_empty = threading.Condition(self.lock)
        self.heap: list[tuple[int, int, str]] = []
        self.sequence = 0
        self.tasks: dict[str, TaskRecord] = {}
        self.in_progress: dict[str, set[str]] = {}
        self.worker_heartbeats: dict[str, float] = {}

    def submit(self, name: str, args: list[Any], kwargs: dict[str, Any], priority: int, payload: Any = None) -> str:
        task_id = str(uuid.uuid4())
        now = time.monotonic()
        task = TaskRecord(
            id=task_id,
            name=name,
            args=args,
            kwargs=kwargs,
            priority=priority,
            created_at=now,
            payload=payload,
            updated_at=now,
        )
        with self.not_empty:
            self.tasks[task_id] = task
            self._push_locked(task)
            self.not_empty.notify()
        return task_id

    def fetch(self, worker_id: str, timeout: float = 0.0) -> TaskRecord | None:
        deadline = time.monotonic() + max(timeout, 0.0)
        with self.not_empty:
            self.worker_heartbeats[worker_id] = time.monotonic()
            while True:
                task = self._pop_locked()
                if task is not None:
                    task.state = "running"
                    task.worker_id = worker_id
                    task.attempts += 1
                    task.updated_at = time.monotonic()
                    self.in_progress.setdefault(worker_id, set()).add(task.id)
                    return task
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return None
                self.not_empty.wait(remaining)

    def heartbeat(self, worker_id: str) -> None:
        with self.lock:
            self.worker_heartbeats[worker_id] = time.monotonic()

    def complete(self, worker_id: str, task_id: str, result: Any) -> bool:
        with self.lock:
            task = self.tasks.get(task_id)
            if task is None or task.state != "running" or task.worker_id != worker_id:
                return False
            task.state = "completed"
            task.result = result
            task.updated_at = time.monotonic()
            self._unassign_locked(worker_id, task_id)
            return True

    def fail(self, worker_id: str, task_id: str, error: str, *, requeue: bool) -> bool:
        with self.not_empty:
            task = self.tasks.get(task_id)
            if task is None or task.state != "running" or task.worker_id != worker_id:
                return False
            self._unassign_locked(worker_id, task_id)
            task.error = error
            task.updated_at = time.monotonic()
            if requeue:
                task.state = "queued"
                task.worker_id = None
                self._push_locked(task)
                self.not_empty.notify()
            else:
                task.state = "failed"
            return True

    def status(self, task_id: str) -> dict[str, Any] | None:
        with self.lock:
            task = self.tasks.get(task_id)
            if task is None:
                return None
            return {
                "id": task.id,
                "name": task.name,
                "priority": task.priority,
                "attempts": task.attempts,
                "state": task.state,
                "worker_id": task.worker_id,
                "result": task.result,
                "error": task.error,
            }

    def requeue_stale(self) -> list[str]:
        now = time.monotonic()
        stale_workers: list[str] = []
        with self.not_empty:
            for worker_id, heartbeat_at in list(self.worker_heartbeats.items()):
                if now - heartbeat_at <= self.heartbeat_timeout:
                    continue
                stale_workers.append(worker_id)
                task_ids = list(self.in_progress.pop(worker_id, set()))
                self.worker_heartbeats.pop(worker_id, None)
                for task_id in task_ids:
                    task = self.tasks.get(task_id)
                    if task is None or task.state in TERMINAL_STATES:
                        continue
                    task.state = "queued"
                    task.worker_id = None
                    task.updated_at = now
                    self._push_locked(task)
            if stale_workers:
                self.not_empty.notify_all()
        return stale_workers

    def _push_locked(self, task: TaskRecord) -> None:
        self.sequence += 1
        heapq.heappush(self.heap, (-task.priority, self.sequence, task.id))

    def _pop_locked(self) -> TaskRecord | None:
        while self.heap:
            _, _, task_id = heapq.heappop(self.heap)
            task = self.tasks.get(task_id)
            if task is not None and task.state == "queued":
                return task
        return None

    def _unassign_locked(self, worker_id: str, task_id: str) -> None:
        assigned = self.in_progress.get(worker_id)
        if assigned is None:
            return
        assigned.discard(task_id)
        if not assigned:
            self.in_progress.pop(worker_id, None)


class _ThreadingServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], handler: type[socketserver.BaseRequestHandler], broker: "Broker") -> None:
        self.broker = broker
        super().__init__(address, handler)


class _BrokerHandler(socketserver.StreamRequestHandler):
    def setup(self) -> None:
        super().setup()
        self.request.settimeout(self.server.broker.config.socket_timeout)  # type: ignore[attr-defined]

    def handle(self) -> None:
        broker: Broker = self.server.broker  # type: ignore[attr-defined]
        request: dict[str, Any] | None = None
        response: dict[str, Any]
        try:
            request = recv_message(self.rfile)
            response = broker.dispatch(request)
        except (EOFError, ProtocolError, ValueError, TypeError) as exc:
            response = {"ok": False, "error": str(exc)}
        try:
            send_message(self.request, response)
        except OSError:
            if request and request.get("op") == "fetch":
                task = response.get("task")
                worker_id = request.get("worker_id")
                if isinstance(task, dict) and isinstance(worker_id, str):
                    task_id = task.get("id")
                    if isinstance(task_id, str):
                        broker.state.fail(worker_id, task_id, "fetch response socket failure", requeue=True)


class Broker:
    """TCP task broker.

    The broker accepts one JSON-lines request per TCP connection. This keeps
    socket ownership simple and makes resource cleanup deterministic.
    """

    def __init__(self, config: BrokerConfig | None = None) -> None:
        self.config = config or BrokerConfig()
        self.state = _QueueState(self.config.heartbeat_timeout)
        self._server: _ThreadingServer | None = None
        self._serve_thread: threading.Thread | None = None
        self._requeue_thread: threading.Thread | None = None
        self._stop = threading.Event()

    @property
    def address(self) -> tuple[str, int]:
        if self._server is None:
            return (self.config.host, self.config.port)
        host, port = self._server.server_address
        return (str(host), int(port))

    def start(self) -> tuple[str, int]:
        if self._server is not None:
            return self.address
        self._server = _ThreadingServer((self.config.host, self.config.port), _BrokerHandler, self)
        self._stop.clear()
        self._serve_thread = threading.Thread(target=self._server.serve_forever, name="taskqueue-broker", daemon=True)
        self._requeue_thread = threading.Thread(target=self._requeue_loop, name="taskqueue-requeue", daemon=True)
        self._serve_thread.start()
        self._requeue_thread.start()
        return self.address

    def stop(self) -> None:
        self._stop.set()
        server = self._server
        if server is not None:
            server.shutdown()
            server.server_close()
        if self._serve_thread is not None:
            self._serve_thread.join(timeout=2)
        if self._requeue_thread is not None:
            self._requeue_thread.join(timeout=2)
        self._server = None
        self._serve_thread = None
        self._requeue_thread = None

    def __enter__(self) -> "Broker":
        self.start()
        return self

    def __exit__(self, *_: object) -> None:
        self.stop()

    def dispatch(self, request: dict[str, Any]) -> dict[str, Any]:
        op = request.get("op")
        if op == "submit":
            return self._submit(request)
        if op == "fetch":
            return self._fetch(request)
        if op == "heartbeat":
            worker_id = _required_str(request, "worker_id")
            self.state.heartbeat(worker_id)
            return {"ok": True}
        if op == "complete":
            accepted = self.state.complete(_required_str(request, "worker_id"), _required_str(request, "task_id"), request.get("result"))
            return {"ok": accepted}
        if op == "fail":
            accepted = self.state.fail(
                _required_str(request, "worker_id"),
                _required_str(request, "task_id"),
                str(request.get("error", "")),
                requeue=bool(request.get("requeue", False)),
            )
            return {"ok": accepted}
        if op == "status":
            status = self.state.status(_required_str(request, "task_id"))
            return {"ok": status is not None, "task": status}
        raise ValueError("unknown operation")

    def _submit(self, request: dict[str, Any]) -> dict[str, Any]:
        name = _required_str(request, "name")
        args = request.get("args", [])
        kwargs = request.get("kwargs", {})
        priority = request.get("priority", 100)
        if not isinstance(args, list):
            raise ValueError("args must be a list")
        if not isinstance(kwargs, dict):
            raise ValueError("kwargs must be an object")
        if not isinstance(priority, int):
            raise ValueError("priority must be an integer")
        task_id = self.state.submit(name, args, kwargs, priority)
        return {"ok": True, "task_id": task_id}

    def _fetch(self, request: dict[str, Any]) -> dict[str, Any]:
        worker_id = _required_str(request, "worker_id")
        timeout = float(request.get("timeout", 0.0))
        task = self.state.fetch(worker_id, timeout=timeout)
        if task is None:
            return {"ok": True, "task": None}
        return {
            "ok": True,
            "task": {
                "id": task.id,
                "name": task.name,
                "args": task.args,
                "kwargs": task.kwargs,
                "payload": task.payload,
                "priority": task.priority,
                "attempts": task.attempts,
            },
        }

    def _requeue_loop(self) -> None:
        while not self._stop.wait(self.config.requeue_interval):
            self.state.requeue_stale()


def _required_str(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"{key} must be a non-empty string")
    return value
