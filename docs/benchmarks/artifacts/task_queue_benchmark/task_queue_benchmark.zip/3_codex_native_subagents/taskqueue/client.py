"""Client API for taskqueue brokers."""

from __future__ import annotations

import socket
import uuid
from typing import Any

from .protocol import ProtocolError, recv_message, send_message


class QueueError(Exception):
    """Raised when a broker request fails."""


class QueueClient:
    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 9999,
        timeout: float = 5.0,
        sock: socket.socket | None = None,
        **kwargs: Any,
    ) -> None:
        existing_socket = kwargs.pop("socket", None)
        if kwargs:
            unexpected = ", ".join(sorted(kwargs))
            raise TypeError(f"unexpected keyword argument(s): {unexpected}")
        self.host = host
        self.port = port
        self.timeout = timeout
        self.sock = sock if sock is not None else existing_socket
        self._owns_socket = self.sock is not None

    def __enter__(self) -> "QueueClient":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def close(self) -> None:
        if self.sock is not None and self._owns_socket:
            self.sock.close()

    def submit(self, name: str, *args: Any, priority: int = 100, **kwargs: Any) -> str:
        response = self.request({"op": "submit", "name": name, "args": list(args), "kwargs": kwargs, "priority": priority})
        return str(response["task_id"])

    def fetch(self, worker_id: str | None = None, *, timeout: float = 0.0) -> dict[str, Any] | None:
        response = self.request({"op": "fetch", "worker_id": worker_id or f"client-{uuid.uuid4()}", "timeout": timeout})
        task = response.get("task")
        if task is not None and not isinstance(task, dict):
            raise QueueError("broker returned invalid task")
        return task

    def heartbeat(self, worker_id: str) -> None:
        self.request({"op": "heartbeat", "worker_id": worker_id})

    def complete(self, worker_id: str, task_id: str, result: Any = None) -> bool:
        return bool(self.request({"op": "complete", "worker_id": worker_id, "task_id": task_id, "result": result}).get("ok"))

    def fail(self, worker_id: str, task_id: str, error: str, *, requeue: bool = False) -> bool:
        return bool(
            self.request({"op": "fail", "worker_id": worker_id, "task_id": task_id, "error": error, "requeue": requeue}).get("ok")
        )

    def status(self, task_id: str) -> dict[str, Any] | None:
        return self.request({"op": "status", "task_id": task_id}).get("task")

    def request(self, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            if self.sock is None:
                with socket.create_connection((self.host, self.port), timeout=self.timeout) as sock:
                    response = self._request_on_socket(sock, payload)
            else:
                response = self._request_on_socket(self.sock, payload)
        except (OSError, EOFError, ProtocolError) as exc:
            raise QueueError(str(exc)) from exc
        if not response.get("ok"):
            raise QueueError(str(response.get("error", "broker rejected request")))
        return response

    def _request_on_socket(self, sock: socket.socket, payload: dict[str, Any]) -> dict[str, Any]:
        sock.settimeout(self.timeout)
        with sock.makefile("rb") as reader:
            send_message(sock, payload)
            return recv_message(reader)
