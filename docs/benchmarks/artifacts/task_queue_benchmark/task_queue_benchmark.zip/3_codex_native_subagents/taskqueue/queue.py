"""In-memory queue facade built on the broker's synchronized queue state."""

from __future__ import annotations

from typing import Any

from .broker import _QueueState


class TaskQueue:
    """Thread-safe in-memory task queue.

    This class is useful for tests and embedding. The TCP `Broker` uses the same
    underlying synchronization model for scheduling and heartbeat expiry.
    """

    def __init__(self, heartbeat_timeout: float = 10.0, visibility_timeout: float | None = None) -> None:
        self.state = _QueueState(visibility_timeout if visibility_timeout is not None else heartbeat_timeout)

    def start(self) -> None:
        return None

    def stop(self) -> None:
        return None

    close = shutdown = stop

    def enqueue(self, payload: Any, priority: int = 100) -> str:
        return self.state.submit("__payload__", [], {}, priority, payload=payload)

    put = submit = add_task = publish = enqueue

    def reserve(self, worker_id: str = "worker") -> dict[str, Any] | None:
        task = self.state.fetch(worker_id, timeout=0.0)
        if task is None:
            return None
        return {
            "id": task.id,
            "task_id": task.id,
            "payload": task.payload,
            "priority": task.priority,
            "attempts": task.attempts,
        }

    dequeue = get = pop = claim = reserve

    def complete(self, task_id: str, worker_id: str = "worker", result: Any = None) -> bool:
        return self.state.complete(worker_id, task_id, result)

    ack = acknowledge = finish = mark_complete = complete

    def fail(self, task_id: str, worker_id: str = "worker", requeue: bool = True, error: str = "") -> bool:
        return self.state.fail(worker_id, task_id, error, requeue=requeue)

    nack = reject = mark_failed = fail

    def heartbeat(self, worker_id: str = "worker") -> None:
        self.state.heartbeat(worker_id)

    touch = renew = ping = heartbeat

    def reap_timeouts(self) -> list[str]:
        return self.state.requeue_stale()

    requeue_expired = check_timeouts = expire_workers = reap_timeouts

    def status(self, task_id: str) -> dict[str, Any] | None:
        return self.state.status(task_id)


Queue = TaskBroker = TaskQueue
