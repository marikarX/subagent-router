"""A small standard-library distributed task queue."""

from .broker import Broker, BrokerConfig
from .client import QueueClient, QueueError
from .queue import Queue, TaskBroker, TaskQueue
from .worker import Worker

Client = TaskQueueClient = QueueClient

__all__ = [
    "Broker",
    "BrokerConfig",
    "Client",
    "Queue",
    "QueueClient",
    "QueueError",
    "TaskBroker",
    "TaskQueue",
    "TaskQueueClient",
    "Worker",
]
