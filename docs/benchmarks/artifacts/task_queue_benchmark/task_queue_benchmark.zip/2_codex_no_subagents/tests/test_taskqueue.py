import socket
import threading
import time
import unittest

from taskqueue.client import TaskQueueClient
from taskqueue.protocol import MAX_MESSAGE_BYTES
from taskqueue.server import QueueState, TaskQueueServer


class QueueStateTests(unittest.TestCase):
    def test_priority_orders_highest_first_and_fifo_for_equal_priority(self):
        state = QueueState()
        low = state.enqueue("job", {"n": 1}, priority=1)
        high = state.enqueue("job", {"n": 2}, priority=10)
        same_a = state.enqueue("job", {"n": 3}, priority=5)
        same_b = state.enqueue("job", {"n": 4}, priority=5)

        self.assertEqual(state.poll("worker").id, high.id)
        state.complete("worker", high.id)
        self.assertEqual(state.poll("worker").id, same_a.id)
        state.complete("worker", same_a.id)
        self.assertEqual(state.poll("worker").id, same_b.id)
        state.complete("worker", same_b.id)
        self.assertEqual(state.poll("worker").id, low.id)

    def test_concurrent_poll_does_not_assign_task_twice(self):
        state = QueueState()
        tasks = [state.enqueue("job", i, priority=i) for i in range(50)]
        assigned = []
        assigned_lock = threading.Lock()

        def poller(worker_id):
            while True:
                task = state.poll(worker_id)
                if task is None:
                    return
                with assigned_lock:
                    assigned.append(task.id)
                state.complete(worker_id, task.id)

        threads = [threading.Thread(target=poller, args=(f"w-{i}",)) for i in range(8)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()

        self.assertCountEqual(assigned, [task.id for task in tasks])
        self.assertEqual(len(assigned), len(set(assigned)))

    def test_stale_worker_requeues_running_task(self):
        state = QueueState(heartbeat_timeout=0.01)
        task = state.enqueue("job", None, priority=0)
        self.assertEqual(state.poll("worker-1").id, task.id)
        time.sleep(0.02)

        self.assertEqual(state.requeue_stale_workers(), [task.id])
        self.assertEqual(state.poll("worker-2").id, task.id)


class ServerClientTests(unittest.TestCase):
    def setUp(self):
        self.server = TaskQueueServer(port=0, heartbeat_timeout=0.05, monitor_interval=0.01)
        self.thread = self.server.start_in_thread()
        self.client = TaskQueueClient(port=self.server.port)

    def tearDown(self):
        self.server.close()

    def test_client_server_lifecycle(self):
        task = self.client.enqueue("job", {"ok": True}, priority=7)
        worker_id = self.client.register("worker")
        polled = self.client.poll(worker_id)
        self.assertEqual(polled["id"], task["id"])
        self.client.heartbeat(worker_id)
        completed = self.client.complete(worker_id, task["id"])
        self.assertEqual(completed["status"], "completed")

    def test_oversized_socket_message_is_rejected_and_connection_closes(self):
        with socket.create_connection((self.server.host, self.server.port), timeout=2.0) as sock:
            sock.sendall(b"x" * (MAX_MESSAGE_BYTES + 2) + b"\n")
            response = sock.recv(4096)
        self.assertIn(b"message exceeds", response)


if __name__ == "__main__":
    unittest.main()
