# Standard-Library Distributed Task Queue

This project implements a TCP task queue in Python without Celery, Redis, or
third-party packages. It supports:

- JSON-lines client/server protocol over TCP
- priority scheduling, where higher integer priority runs first
- FIFO ordering among tasks with the same priority
- worker registration and heartbeats
- stale worker detection with automatic requeue of in-flight tasks
- bounded socket messages to avoid unbounded memory growth from peers

Run the tests:

```bash
python -m unittest
```

Minimal usage:

```python
from taskqueue import TaskQueueClient, TaskQueueServer, Worker

server = TaskQueueServer(port=8765)
server.start_in_thread()

client = TaskQueueClient(port=8765)
client.enqueue("print", {"message": "hello"}, priority=10)

worker = Worker(client, {"print": lambda payload: print(payload["message"])})
worker.run_forever()
```
