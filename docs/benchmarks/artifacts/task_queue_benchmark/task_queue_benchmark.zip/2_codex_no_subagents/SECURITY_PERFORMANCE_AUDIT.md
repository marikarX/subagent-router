# Security and Performance Audit

## Race Conditions in the Priority Queue

- All heap, task, worker, and sequence mutations are guarded by a single
  `threading.Condition` in `QueueState`.
- `enqueue`, `poll`, `complete`, `fail`, and stale-worker requeueing never touch
  `_heap` without holding the condition lock.
- Heap entries contain `(-priority, sequence, task_id)`, so higher integer
  priority runs first and same-priority tasks preserve FIFO order.
- Requeued tasks create a new heap entry. `_pop_ready_locked` discards stale
  entries by checking the authoritative task table for `status == "queued"` and
  `worker_id is None` while still under lock.
- `poll` atomically pops, marks the task running, increments attempts, and
  assigns `worker_id` before releasing the lock. That prevents two workers from
  receiving the same task.

Residual risk: one global lock limits throughput under very high worker counts,
but it strongly favors correctness. Sharding by queue would be the next scaling
step if contention appears in profiling.

## Socket-Level Memory Leak Checks

- The protocol is newline-delimited JSON with `MAX_MESSAGE_BYTES = 65536`.
  `readline(MAX_MESSAGE_BYTES + 1)` rejects oversized client messages before
  they can grow memory without bound.
- The client opens one socket per request with `socket.create_connection(...)`
  in a context manager and explicitly closes both `makefile` wrappers.
- The server uses `socketserver.StreamRequestHandler`; handler file wrappers are
  closed by the base class after `handle` returns.
- Server threads are daemonized and connections have a socket timeout, limiting
  idle peer resource retention.
- Responses are also size-checked before being written.

Residual risk: `ThreadingMixIn` creates one thread per connection. This is
simple and leak-resistant for normal use, but a hostile peer can still consume
threads by opening many concurrent idle connections until the socket timeout.
A production hardening pass should add connection limits or a selector-based
server loop.

## Performance Notes

- Enqueue and dequeue operations are `O(log n)`.
- Completing and heartbeat operations are `O(1)`.
- Stale worker scanning is `O(workers)` per monitor interval.
- Heap stale-entry cleanup is amortized: failed or requeued task duplicates are
  discarded lazily during polling.
