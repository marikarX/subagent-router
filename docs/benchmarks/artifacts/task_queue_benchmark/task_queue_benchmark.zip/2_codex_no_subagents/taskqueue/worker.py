"""Worker runtime for executing registered Python callables."""

from __future__ import annotations

import threading
import time
from collections.abc import Callable
from typing import Any

from .client import TaskQueueClient


TaskHandler = Callable[[Any], None]


class Worker:
    def __init__(
        self,
        client: TaskQueueClient,
        handlers: dict[str, TaskHandler],
        *,
        worker_id: str | None = None,
        heartbeat_interval: float = 5.0,
        poll_timeout: float = 1.0,
    ) -> None:
        self.client = client
        self.handlers = handlers
        self.worker_id = worker_id
        self.heartbeat_interval = heartbeat_interval
        self.poll_timeout = poll_timeout
        self._stop = threading.Event()
        self._heartbeat_thread: threading.Thread | None = None

    def run_forever(self) -> None:
        self.worker_id = self.client.register(self.worker_id)
        self._heartbeat_thread = threading.Thread(target=self._send_heartbeats, daemon=True)
        self._heartbeat_thread.start()
        try:
            while not self._stop.is_set():
                task = self.client.poll(self.worker_id, timeout=self.poll_timeout)
                if task is None:
                    continue
                self._run_task(task)
        finally:
            self.stop()

    def stop(self) -> None:
        self._stop.set()
        if self._heartbeat_thread is not None and self._heartbeat_thread.is_alive():
            self._heartbeat_thread.join(timeout=self.heartbeat_interval + 1.0)

    def _send_heartbeats(self) -> None:
        while not self._stop.wait(self.heartbeat_interval):
            if self.worker_id is not None:
                self.client.heartbeat(self.worker_id)

    def _run_task(self, task: dict[str, Any]) -> None:
        assert self.worker_id is not None
        handler = self.handlers.get(task["name"])
        if handler is None:
            self.client.fail(self.worker_id, task["id"], requeue=False)
            return
        try:
            handler(task["payload"])
        except Exception:
            self.client.fail(self.worker_id, task["id"], requeue=True)
            time.sleep(0.1)
            return
        self.client.complete(self.worker_id, task["id"])
