"""Client for the standard-library task queue server."""

from __future__ import annotations

import socket
from typing import Any

from .protocol import read_message, write_message


class TaskQueueClient:
    def __init__(self, host: str = "127.0.0.1", port: int = 8765, *, timeout: float = 10.0) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout

    def enqueue(self, name: str, payload: Any = None, *, priority: int = 0) -> dict[str, Any]:
        return self._request({"action": "enqueue", "name": name, "payload": payload, "priority": priority})["task"]

    def register(self, worker_id: str | None = None) -> str:
        request: dict[str, Any] = {"action": "register"}
        if worker_id is not None:
            request["worker_id"] = worker_id
        return self._request(request)["worker_id"]

    def heartbeat(self, worker_id: str) -> None:
        self._request({"action": "heartbeat", "worker_id": worker_id})

    def poll(self, worker_id: str, *, timeout: float = 0.0) -> dict[str, Any] | None:
        return self._request({"action": "poll", "worker_id": worker_id, "timeout": timeout})["task"]

    def complete(self, worker_id: str, task_id: str) -> dict[str, Any]:
        return self._request({"action": "complete", "worker_id": worker_id, "task_id": task_id})["task"]

    def fail(self, worker_id: str, task_id: str, *, requeue: bool = True) -> dict[str, Any]:
        return self._request(
            {"action": "fail", "worker_id": worker_id, "task_id": task_id, "requeue": requeue}
        )["task"]

    def stats(self) -> dict[str, Any]:
        return self._request({"action": "stats"})["stats"]

    def _request(self, message: dict[str, Any]) -> dict[str, Any]:
        with socket.create_connection((self.host, self.port), timeout=self.timeout) as sock:
            sock.settimeout(self.timeout)
            reader = sock.makefile("rb")
            writer = sock.makefile("wb")
            try:
                write_message(writer, message)
                response = read_message(reader)
            finally:
                reader.close()
                writer.close()
        if not response.get("ok"):
            raise RuntimeError(response.get("error", "task queue request failed"))
        return response
