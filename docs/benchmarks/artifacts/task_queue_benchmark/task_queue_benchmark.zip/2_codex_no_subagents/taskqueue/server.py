"""TCP task queue server implemented with standard-library primitives."""

from __future__ import annotations

import heapq
import socketserver
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from .protocol import ProtocolError, read_message, write_message


class TaskQueueError(RuntimeError):
    """Base queue error."""


@dataclass(slots=True)
class Task:
    id: str
    name: str
    payload: Any
    priority: int
    attempts: int = 0
    status: str = "queued"
    worker_id: str | None = None
    created_at: float = field(default_factory=time.monotonic)
    updated_at: float = field(default_factory=time.monotonic)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "payload": self.payload,
            "priority": self.priority,
            "attempts": self.attempts,
            "status": self.status,
            "worker_id": self.worker_id,
        }


@dataclass(slots=True)
class WorkerState:
    id: str
    last_heartbeat: float
    current_task_id: str | None = None


class QueueState:
    """Thread-safe task and worker state.

    The heap, task table, worker table, and sequence counter are protected by a
    single condition lock. That keeps poll/enqueue/requeue/complete atomic with
    respect to each other and avoids races around stale heap entries.
    """

    def __init__(self, *, heartbeat_timeout: float = 30.0) -> None:
        self.heartbeat_timeout = heartbeat_timeout
        self._condition = threading.Condition()
        self._heap: list[tuple[int, int, str]] = []
        self._tasks: dict[str, Task] = {}
        self._workers: dict[str, WorkerState] = {}
        self._sequence = 0

    def enqueue(self, name: str, payload: Any, priority: int = 0) -> Task:
        if not isinstance(name, str) or not name:
            raise TaskQueueError("task name must be a non-empty string")
        if not isinstance(priority, int):
            raise TaskQueueError("priority must be an integer")
        task = Task(id=str(uuid.uuid4()), name=name, payload=payload, priority=priority)
        with self._condition:
            self._tasks[task.id] = task
            self._push_locked(task)
            self._condition.notify()
            return task

    def register_worker(self, worker_id: str | None = None) -> WorkerState:
        worker_id = worker_id or str(uuid.uuid4())
        if not isinstance(worker_id, str) or not worker_id:
            raise TaskQueueError("worker_id must be a non-empty string")
        now = time.monotonic()
        with self._condition:
            worker = self._workers.get(worker_id)
            if worker is None:
                worker = WorkerState(id=worker_id, last_heartbeat=now)
                self._workers[worker_id] = worker
            else:
                worker.last_heartbeat = now
            return worker

    def heartbeat(self, worker_id: str) -> WorkerState:
        with self._condition:
            worker = self._workers.get(worker_id)
            if worker is None:
                worker = WorkerState(id=worker_id, last_heartbeat=time.monotonic())
                self._workers[worker_id] = worker
            else:
                worker.last_heartbeat = time.monotonic()
            return worker

    def poll(self, worker_id: str, *, timeout: float = 0.0) -> Task | None:
        deadline = time.monotonic() + max(timeout, 0.0)
        with self._condition:
            worker = self._workers.get(worker_id)
            if worker is None:
                worker = WorkerState(id=worker_id, last_heartbeat=time.monotonic())
                self._workers[worker_id] = worker
            else:
                worker.last_heartbeat = time.monotonic()
            while True:
                task = self._pop_ready_locked()
                if task is not None:
                    task.status = "running"
                    task.worker_id = worker_id
                    task.attempts += 1
                    task.updated_at = time.monotonic()
                    worker.current_task_id = task.id
                    return task
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return None
                self._condition.wait(remaining)

    def complete(self, worker_id: str, task_id: str) -> Task:
        with self._condition:
            task = self._require_task_locked(task_id)
            if task.status != "running" or task.worker_id != worker_id:
                raise TaskQueueError("task is not running for this worker")
            task.status = "completed"
            task.updated_at = time.monotonic()
            self._clear_worker_task_locked(worker_id, task_id)
            return task

    def fail(self, worker_id: str, task_id: str, *, requeue: bool = True) -> Task:
        with self._condition:
            task = self._require_task_locked(task_id)
            if task.status != "running" or task.worker_id != worker_id:
                raise TaskQueueError("task is not running for this worker")
            self._clear_worker_task_locked(worker_id, task_id)
            task.worker_id = None
            task.updated_at = time.monotonic()
            if requeue:
                task.status = "queued"
                self._push_locked(task)
                self._condition.notify()
            else:
                task.status = "failed"
            return task

    def requeue_stale_workers(self) -> list[str]:
        now = time.monotonic()
        requeued: list[str] = []
        with self._condition:
            for worker_id, worker in list(self._workers.items()):
                if now - worker.last_heartbeat <= self.heartbeat_timeout:
                    continue
                task_id = worker.current_task_id
                if task_id is not None:
                    task = self._tasks.get(task_id)
                    if task is not None and task.status == "running" and task.worker_id == worker_id:
                        task.status = "queued"
                        task.worker_id = None
                        task.updated_at = now
                        self._push_locked(task)
                        requeued.append(task.id)
                del self._workers[worker_id]
            if requeued:
                self._condition.notify_all()
            return requeued

    def stats(self) -> dict[str, Any]:
        with self._condition:
            by_status: dict[str, int] = {}
            for task in self._tasks.values():
                by_status[task.status] = by_status.get(task.status, 0) + 1
            return {
                "tasks": by_status,
                "workers": len(self._workers),
                "queued_heap_entries": len(self._heap),
            }

    def _push_locked(self, task: Task) -> None:
        self._sequence += 1
        heapq.heappush(self._heap, (-task.priority, self._sequence, task.id))

    def _pop_ready_locked(self) -> Task | None:
        while self._heap:
            _priority, _sequence, task_id = heapq.heappop(self._heap)
            task = self._tasks.get(task_id)
            if task is not None and task.status == "queued" and task.worker_id is None:
                return task
        return None

    def _require_task_locked(self, task_id: str) -> Task:
        task = self._tasks.get(task_id)
        if task is None:
            raise TaskQueueError("unknown task_id")
        return task

    def _clear_worker_task_locked(self, worker_id: str, task_id: str) -> None:
        worker = self._workers.get(worker_id)
        if worker is not None and worker.current_task_id == task_id:
            worker.current_task_id = None
            worker.last_heartbeat = time.monotonic()


class _RequestHandler(socketserver.StreamRequestHandler):
    def handle(self) -> None:
        self.request.settimeout(self.server.socket_timeout)
        while True:
            try:
                request = read_message(self.rfile)
                response = self.server.dispatch(request)
            except EOFError:
                return
            except (ProtocolError, TaskQueueError) as exc:
                response = {"ok": False, "error": str(exc)}
            write_message(self.wfile, response)


class _ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True


class TaskQueueServer:
    """Network task queue server.

    Protocol actions are JSON objects over newline-delimited TCP:
    enqueue, register, heartbeat, poll, complete, fail, and stats.
    """

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 8765,
        *,
        heartbeat_timeout: float = 30.0,
        monitor_interval: float = 1.0,
        socket_timeout: float = 60.0,
    ) -> None:
        self.state = QueueState(heartbeat_timeout=heartbeat_timeout)
        self.monitor_interval = monitor_interval
        self._stop = threading.Event()
        self._server = _ThreadedTCPServer((host, port), _RequestHandler)
        self._server.state = self.state  # type: ignore[attr-defined]
        self._server.dispatch = self.dispatch  # type: ignore[attr-defined]
        self._server.socket_timeout = socket_timeout  # type: ignore[attr-defined]
        self._monitor = threading.Thread(target=self._monitor_stale_workers, daemon=True)
        self.host, self.port = self._server.server_address

    def serve_forever(self) -> None:
        self._monitor.start()
        try:
            self._server.serve_forever(poll_interval=0.2)
        finally:
            self.close()

    def start_in_thread(self) -> threading.Thread:
        thread = threading.Thread(target=self.serve_forever, daemon=True)
        thread.start()
        return thread

    def close(self) -> None:
        self._stop.set()
        self._server.shutdown()
        self._server.server_close()
        if self._monitor.is_alive() and threading.current_thread() is not self._monitor:
            self._monitor.join(timeout=2.0)

    def dispatch(self, request: dict[str, Any]) -> dict[str, Any]:
        action = request.get("action")
        if action == "enqueue":
            task = self.state.enqueue(
                name=request.get("name"),
                payload=request.get("payload"),
                priority=request.get("priority", 0),
            )
            return {"ok": True, "task": task.to_dict()}
        if action == "register":
            worker = self.state.register_worker(request.get("worker_id"))
            return {"ok": True, "worker_id": worker.id}
        if action == "heartbeat":
            worker_id = self._string_field(request, "worker_id")
            self.state.heartbeat(worker_id)
            return {"ok": True}
        if action == "poll":
            worker_id = self._string_field(request, "worker_id")
            timeout = float(request.get("timeout", 0.0))
            task = self.state.poll(worker_id, timeout=timeout)
            return {"ok": True, "task": None if task is None else task.to_dict()}
        if action == "complete":
            task = self.state.complete(
                self._string_field(request, "worker_id"),
                self._string_field(request, "task_id"),
            )
            return {"ok": True, "task": task.to_dict()}
        if action == "fail":
            task = self.state.fail(
                self._string_field(request, "worker_id"),
                self._string_field(request, "task_id"),
                requeue=bool(request.get("requeue", True)),
            )
            return {"ok": True, "task": task.to_dict()}
        if action == "stats":
            return {"ok": True, "stats": self.state.stats()}
        raise ProtocolError("unknown action")

    def _monitor_stale_workers(self) -> None:
        while not self._stop.wait(self.monitor_interval):
            self.state.requeue_stale_workers()

    @staticmethod
    def _string_field(request: dict[str, Any], field_name: str) -> str:
        value = request.get(field_name)
        if not isinstance(value, str) or not value:
            raise ProtocolError(f"{field_name} must be a non-empty string")
        return value
