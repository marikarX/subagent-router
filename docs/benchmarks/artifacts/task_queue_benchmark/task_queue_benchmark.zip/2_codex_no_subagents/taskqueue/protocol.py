"""Shared protocol helpers for the task queue."""

from __future__ import annotations

import json
from typing import Any, BinaryIO


MAX_MESSAGE_BYTES = 64 * 1024


class ProtocolError(ValueError):
    """Raised when a peer sends an invalid request."""


def read_message(reader: BinaryIO) -> dict[str, Any]:
    line = reader.readline(MAX_MESSAGE_BYTES + 1)
    if not line:
        raise EOFError
    if len(line) > MAX_MESSAGE_BYTES:
        raise ProtocolError("message exceeds 65536 bytes")
    try:
        message = json.loads(line.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProtocolError("message must be a JSON object line") from exc
    if not isinstance(message, dict):
        raise ProtocolError("message must be a JSON object")
    return message


def write_message(writer: BinaryIO, message: dict[str, Any]) -> None:
    encoded = json.dumps(message, separators=(",", ":"), sort_keys=True).encode("utf-8")
    if len(encoded) > MAX_MESSAGE_BYTES:
        raise ProtocolError("response exceeds 65536 bytes")
    writer.write(encoded + b"\n")
    writer.flush()
